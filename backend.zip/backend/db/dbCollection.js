const mongoose = require('mongoose');

const connectDb = async () => {
    try {
        await mongoose.connect('mongodb://127.0.0.1:27017/react-login-tut');
        console.log('Connected to MongoDB');
    } catch (error) {
        console.error("Not Connected", error);
    }
}

module.exports = connectDb;
